How to use:

1. Open powershell with administrative privileges
2. Change directory to the folder where "folder_access.ps1" and this README is located
3. Run this command -> ./folder_access.ps1 "username" "path" "OPTIONAL:read"

Program arguments:

username: this is the username of the user (their ICIG username)
path: this is the path to the folder they want access to (you can use drive names like "W:\..." or full path like "cp4boufs101\...")
read: this is an optional argument. if you want to guarentee the user cannot gain any write or modify access set this equal to "read"

Known Bugs:
I think I worked out all of the bugs so far but if there is any problems let me (Nick) know!

![Alt Text](./use.png)